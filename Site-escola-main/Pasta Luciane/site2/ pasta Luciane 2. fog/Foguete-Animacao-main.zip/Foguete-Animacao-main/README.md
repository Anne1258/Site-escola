# Foguete-Animacao
 Foguete-Animacao
 
 https://youtu.be/84vHChfC1Ik
 
 [![Everything Is AWESOME](https://img.youtube.com/vi/84vHChfC1Ik/0.jpg)](https://youtu.be/84vHChfC1Ik "Everything Is AWESOME")

Simples animação de um foguete no espaço , feita com html css e javascript.
Este foguete animado pode ser a base para um simples jogo de javascript.

Foguete puro css3 viajando por efeitos especiais de animação espacial
O efeito de lançamento de foguete realizado pelo puro css3, o efeito de animação do salto de foguete CSS no espaço.

Como fazer uma animação foguete em html css e javascript
Tutorial de como fazer em html/css e javascript somente.

Animações CSS tornam possível animar transições de um estilo CSS para outro. Animações se consistem de dois componentes: um estilo descrevendo a animação e um set de keyframes que indicam o estado final e inicial do estilo CSS da animação, bem como possíveis waypoints intermediários ao longo do caminho.

Existem três vantagens chave para animações CSS além das técnicas tradicionais de animação dirigidas por script:

São de fácil utilização para animações simples; você pode criá-las sem mesmo ter que conhecer JavaScript.
As animações executam bem, mesmo sobre moderada carga do sistema. Animações simples podem normalmente ser executadas precariamente em JavaScript (a não ser que sejam bem feitas). A ferramenta de renderização pode usar frame-skipping e outras técnicas para manter a performance o mais estável possível.
Deixando o navegador controlar a sequência de animação permite ao navegador otimizar a performance e eficiência em, por exemplo, reduzir a frequência de update de animações correndo em abas que não estão visíveis no momento.

Deixe o Like e inscreva-se no canal para mais conteúdos.
Comente se você gostou do vídeo.

Obrigado.

------------------------------
WebSite: https://resolvendobug.com.br/
Instagram: https://www.instagram.com/resolvendobug/
GitHub: https://github.com/resolvendobug/
------------------------------
Curso que recomendo:
Programador Full Stack
https://bit.ly/3FwewsA

--- NÃO CLIQUE AQUI ---
https://bit.ly/37E1ZHn

#animacaocss
#animacaohtmlcss
#animacaohtmlcssjavascript
#projetogamejavascript
#foguetecssanimado
#foguete animado
